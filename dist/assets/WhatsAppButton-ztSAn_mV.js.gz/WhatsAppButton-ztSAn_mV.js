import{j as e}from"./ui-BLUv2tW2.js";import{M as n}from"./message-circle-DTisseid.js";const r=()=>{const t=()=>{const o=encodeURIComponent("Hello! I'm interested in learning more about your AI ERP solutions.");window.open(`https://wa.me/17324703888?text=${o}`,"_blank")};return e.jsxs(e.Fragment,{children:[e.jsxs("button",{onClick:t,className:"fixed bottom-4 right-4 sm:bottom-6 sm:right-6 md:bottom-8 md:right-8 w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all duration-300 z-50 animate-bounce-slow group touch-manipulation","aria-label":"Chat on WhatsApp",children:[e.jsx(n,{className:"w-7 h-7 sm:w-8 sm:h-8 text-white group-hover:rotate-12 transition-transform"}),e.jsx("span",{className:"absolute -top-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 bg-red-500 rounded-full animate-ping"}),e.jsx("span",{className:"absolute -top-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 bg-red-500 rounded-full"})]}),e.jsx("style",{children:`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        
        .animate-bounce-slow {
          animation: bounce-slow 2s infinite;
        }
        
        /* Ensure button doesn't interfere with mobile navigation */
        @media (max-width: 640px) {
          .animate-bounce-slow {
            animation: none; /* Reduce animation on mobile to save performance */
          }
        }
      `})]})};export{r as W};
